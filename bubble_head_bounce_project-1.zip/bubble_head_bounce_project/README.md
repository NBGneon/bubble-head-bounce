# Bubble Head Bounce

Complete offline Android 2D arcade game source using the seven supplied artworks.

## Build
1. Open the `game` folder in Android Studio.
2. Let Gradle sync.
3. Run `app` on an Android phone/emulator.

Or push this folder to GitHub and run **Actions → Build Bubble Head Bounce APK → Run workflow**. The workflow produces `app-debug.apk` as an artifact.

## Gameplay
- Image 1 is the gameplay head.
- Image 2 is the final victory character.
- Image 3 is the intended lose reaction asset.
- Image 4 is the retry screen artwork.
- Images 5–7 are used as UI/decorative reference assets.
- Score is cumulative and not capped at 50.
- Level targets are 50, 100, 150 … 500.
- Completing 500 wins the full 10-level run.
- Drag/touch left and right to move.
- Bomb frequency and speed increase with progression.
- Best score is saved locally.
