package com.bubbleheadbounce.game;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.MotionEvent;
import android.view.View;
import java.util.*;

public class GameView extends View {
    enum State { MENU, PLAYING, PAUSED, GAME_OVER, WIN }
    static class Falling { float x,y,vy,r,phase; boolean bomb; int color; Falling(float x,float y,float vy,float r,boolean bomb,int color){this.x=x;this.y=y;this.vy=vy;this.r=r;this.bomb=bomb;this.color=color;phase=(float)(Math.random()*6.28);} }
    static class Pop { float x,y,t; int color; Pop(float x,float y,int c){this.x=x;this.y=y;this.color=c;} }

    final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); final Paint stroke=new Paint(Paint.ANTI_ALIAS_FLAG); final Random rng=new Random();
    Bitmap head,win,lose,retry,uiGlasses,uiSunglasses,uiOnam; State state=State.MENU;
    ArrayList<Falling> objects=new ArrayList<>(); ArrayList<Pop> pops=new ArrayList<>();
    float playerX, targetX, lastTime; boolean dragging=false; int score=0, level=1; int best;
    long lastSpawn=0, shakeUntil=0, levelBannerUntil=0; String banner=""; SharedPreferences prefs;
    RectF dst=new RectF();

    public GameView(Context c){ super(c); setLayerType(View.LAYER_TYPE_SOFTWARE,null);
        head=load(c, com.bubbleheadbounce.game.R.drawable.head); win=load(c,R.drawable.win); lose=load(c,R.drawable.lose); retry=load(c,R.drawable.retry);
        uiGlasses=load(c,R.drawable.ui_glasses); uiSunglasses=load(c,R.drawable.ui_sunglasses); uiOnam=load(c,R.drawable.ui_onam);
        prefs=c.getSharedPreferences("scores",Context.MODE_PRIVATE); best=prefs.getInt("best",0); lastTime=System.nanoTime()/1e9f;
        p.setTypeface(Typeface.create("sans",Typeface.BOLD)); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(3);
    }
    Bitmap load(Context c,int id){return BitmapFactory.decodeResource(c.getResources(),id);}
    float W(){return getWidth();} float H(){return getHeight();}
    void txt(Canvas c,String s,float x,float y,float size,int color,Paint.Align a){p.setStyle(Paint.Style.FILL);p.setTextSize(size);p.setColor(color);p.setTextAlign(a);p.setTypeface(Typeface.create("sans",Typeface.BOLD));c.drawText(s,x,y,p);}
    void round(Canvas c,float l,float t,float r,float b,float rad,int color){p.setStyle(Paint.Style.FILL);p.setColor(color);c.drawRoundRect(l,t,r,b,rad,rad,p);}
    void button(Canvas c,String label,float cx,float cy,float bw,float bh){round(c,cx-bw/2,cy-bh/2,cx+bw/2,cy+bh/2,bh*.25f,0xff182442);stroke.setColor(0xff4e79ff);stroke.setStrokeWidth(3);c.drawRoundRect(cx-bw/2,cy-bh/2,cx+bw/2,cy+bh/2,bh*.25f,bh*.25f,stroke);txt(c,label,cx,cy+bh*.12f,bh*.35f,Color.WHITE,Paint.Align.CENTER);}

    @Override protected void onDraw(Canvas c){super.onDraw(c); float now=System.nanoTime()/1e9f; float dt=Math.min(.05f,now-lastTime); lastTime=now;
        if(state==State.PLAYING) update(dt,now);
        drawBackground(c,now);
        if(state==State.MENU) drawMenu(c);
        else if(state==State.PLAYING || state==State.PAUSED) drawGame(c,now);
        else if(state==State.GAME_OVER) drawGameOver(c);
        else drawWin(c);
        postInvalidateOnAnimation();
    }
    void drawBackground(Canvas c,float t){
        LinearGradient g=new LinearGradient(0,0,0,H(),0xff071226,0xff151038,Shader.TileMode.CLAMP);p.setShader(g);c.drawRect(0,0,W(),H(),p);p.setShader(null);
        p.setStyle(Paint.Style.FILL); for(int i=0;i<30;i++){float x=(i*97+((t*8)%97))%W();float y=(i*173)%H();p.setColor(0x22ffffff);c.drawCircle(x,y,2+(i%3),p);} 
    }
    void drawMenu(Canvas c){
        txt(c,"BUBBLE HEAD",W()/2,110,42,0xff70f6ff,Paint.Align.CENTER); txt(c,"BOUNCE",W()/2,154,42,0xffffe36b,Paint.Align.CENTER);
        // head preview
        drawBitmap(c,head,new RectF(W()/2-125,185,W()/2+125,430),0);
        round(c,18,H()-92,W()-18,H()-18,28,0xaa0b1020); txt(c,"BEST SCORE  "+best,30,H()-55,20,0xffdbe7ff,Paint.Align.LEFT);
        button(c,"PLAY",W()/2,485,230,64); button(c,"HOW TO PLAY",W()/2,570,230,60); button(c,"BEST SCORE",W()/2,650,230,60);
        txt(c,"10 LEVELS • 50 → 500",W()/2,H()-125,17,0xff8da3c7,Paint.Align.CENTER);
        // small UI references as decorative badges
        drawBitmap(c,uiSunglasses,new RectF(18,18,92,130),0); drawBitmap(c,uiOnam,new RectF(W()-100,18,W()-18,130),0);
    }
    void drawGame(Canvas c,float t){
        // HUD
        round(c,14,14,W()-14,90,24,0xcc0a1328); txt(c,"SCORE  "+score,W()/2,52,28,Color.WHITE,Paint.Align.CENTER); txt(c,"BEST "+best,28,79,14,0xff9fb3d8,Paint.Align.LEFT); txt(c,"LV "+level+" / 10",W()-28,79,14,0xffffdf65,Paint.Align.RIGHT);
        round(c,W()-68,20,W()-20,68,18,0xff253456); txt(c,"Ⅱ",W()-44,53,25,Color.WHITE,Paint.Align.CENTER);
        // objects
        for(Falling f:objects) drawObject(c,f);
        float pw=Math.min(W()*.72f,420), ph=pw; RectF d=new RectF(playerX-pw/2,H()-ph-22,playerX+pw/2,H()-22); drawBitmap(c,head,d,0);
        for(Pop q:pops){float a=Math.max(0,1-q.t/0.6f);txt(c,"+1",q.x,q.y-q.t*55,24,(int)(a*255)<<24|0xffffef5a,Paint.Align.CENTER);}
        if(levelBannerUntil>System.currentTimeMillis()){round(c,W()/2-155,H()/2-60,W()/2+155,H()/2+60,24,0xee16264b);txt(c,banner,W()/2,H()/2+8,28,0xffffe16b,Paint.Align.CENTER);}
        if(state==State.PAUSED){round(c,0,0,W(),H(),0,0xaa000000);txt(c,"PAUSED",W()/2,H()/2-25,42,Color.WHITE,Paint.Align.CENTER);button(c,"RESUME",W()/2,H()/2+55,220,62);button(c,"MAIN MENU",W()/2,H()/2+130,220,58);}
    }
    void drawObject(Canvas c,Falling f){
        float bob=(float)Math.sin(f.phase+f.y*.02)*2; if(f.bomb){
            p.setStyle(Paint.Style.FILL);p.setColor(0xff171a22);c.drawCircle(f.x,f.y,f.r,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);p.setColor(0xff555b6e);c.drawCircle(f.x,f.y,f.r,p);
            p.setStyle(Paint.Style.FILL);p.setColor(0xffffd34d);c.drawCircle(f.x+f.r*.45f,f.y-f.r*.7f,4,p);stroke.setColor(0xffef6a45);stroke.setStrokeWidth(5);c.drawLine(f.x+f.r*.35f,f.y-f.r*.65f,f.x+f.r*.8f,f.y-f.r*1.15f,stroke);c.drawCircle(f.x+f.r*.88f,f.y-f.r*1.2f,6,p);
            txt(c,"!",f.x,f.y+8,22,Color.WHITE,Paint.Align.CENTER);
        } else {p.setStyle(Paint.Style.FILL);p.setColor(f.color);c.drawCircle(f.x,f.y+bob,f.r,p);p.setColor(0x99ffffff);c.drawCircle(f.x-f.r*.3f,f.y-f.r*.35f,f.r*.24f,p);stroke.setColor(0x88ffffff);stroke.setStrokeWidth(2);c.drawCircle(f.x,f.y,f.r,stroke);}
    }
    void drawGameOver(Canvas c){
        round(c,20,45,W()-20,H()-35,32,0xee10172a); txt(c,"AYYOOO! ENTE THALA POYI! 😂",W()/2,92,22,0xffff6f73,Paint.Align.CENTER); txt(c,"Njan UMFI",W()/2,124,18,0xffd6def2,Paint.Align.CENTER);txt(c,"GAME OVER",W()/2,170,38,Color.WHITE,Paint.Align.CENTER);txt(c,"SCORE: "+score,W()/2,204,24,0xffffdf65,Paint.Align.CENTER);
        drawBitmap(c,retry,new RectF(W()/2-115,225,W()/2+115,520),0);txt(c,"BETTER LUCK NEXT TIME!",W()/2,548,25,0xff70f6ff,Paint.Align.CENTER);button(c,"PLAY AGAIN",W()/2,630,220,60);button(c,"MAIN MENU",W()/2,705,220,58);
    }
    void drawWin(Canvas c){
        round(c,18,35,W()-18,H()-30,34,0xee10243a); txt(c,"Njan Jeyiccheee 🙌😮‍💨",W()/2,88,24,0xffffe36b,Paint.Align.CENTER);txt(c,"GAME WON! 🎉",W()/2,128,40,0xff70f6ff,Paint.Align.CENTER);txt(c,"FINAL SCORE: "+score,W()/2,162,23,Color.WHITE,Paint.Align.CENTER);
        for(int i=0;i<45;i++){float x=(i*83+37)%W();float y=190+((i*67)%360);p.setColor(new int[]{0xffff5d73,0xff62f3ff,0xffffdc4d,0xffb178ff}[i%4]);c.drawRect(x,y,x+6,y+13,p);}
        drawBitmap(c,win,new RectF(W()/2-150,205,W()/2+150,610),0);txt(c,"10 / 10 LEVELS COMPLETE",W()/2,635,19,0xff9fb3d8,Paint.Align.CENTER);button(c,"PLAY AGAIN",W()/2,700,220,58);button(c,"MAIN MENU",W()/2,770,220,55);
    }
    void drawBitmap(Canvas c,Bitmap b,RectF d,int alpha){if(b==null)return;p.setAlpha(alpha==0?255:alpha);c.drawBitmap(b,null,d,p);p.setAlpha(255);}

    void start(){state=State.PLAYING;objects.clear();pops.clear();score=0;level=1;playerX=W()/2;targetX=playerX;lastSpawn=System.currentTimeMillis();}
    void update(float dt,float now){
        playerX += (targetX-playerX)*Math.min(1,dt*12);
        long ms=System.currentTimeMillis(); float speed=260+level*24+score*3.2f; long spawn=(long)Math.max(220,700-level*40-score*1.5f);
        if(ms-lastSpawn>spawn){spawnObject(speed);lastSpawn=ms;}
        Iterator<Falling> it=objects.iterator();while(it.hasNext()){Falling f=it.next();f.y+=f.vy*dt;f.phase+=dt*4;
            float headR=Math.min(W()*.36f,210), hx=playerX, hy=H()-headR*.62f-22;
            if(Math.hypot(f.x-hx,f.y-hy)<f.r+headR*.48f){ if(f.bomb){gameOver();return;} else {score++;pops.add(new Pop(f.x,f.y,Color.WHITE));it.remove();checkLevel();continue;} }
            if(f.y>H()+80)it.remove();
        }
        for(Pop q:pops)q.t+=dt; pops.removeIf(q->q.t>.65f);
    }
    void spawnObject(float speed){
        float r=18+rng.nextFloat()*10; float x=30+rng.nextFloat()*(W()-60); boolean bomb;
        float bombChance=Math.min(.34f,.045f+level*.018f+score*.0016f); bomb=rng.nextFloat()<bombChance;
        int[] colors={0xff58d8ff,0xffff6ba6,0xffffd45c,0xff9b7cff,0xff64e887}; int col=colors[rng.nextInt(colors.length)];
        objects.add(new Falling(x,-r-10,speed*(.78f+rng.nextFloat()*.42f),r,bomb,col));
    }
    void checkLevel(){
        int target=level*50; if(score>=target){if(level<10){level++;banner="LEVEL "+(level-1)+" COMPLETE!";levelBannerUntil=System.currentTimeMillis()+1000;}else win();}
    }
    void gameOver(){state=State.GAME_OVER;objects.clear();if(score>best){best=score;prefs.edit().putInt("best",best).apply();}}
    void win(){state=State.WIN;objects.clear();if(score>best){best=score;prefs.edit().putInt("best",best).apply();}}

    @Override public boolean onTouchEvent(MotionEvent e){float x=e.getX(),y=e.getY();
        if(e.getAction()==MotionEvent.ACTION_DOWN){
            if(state==State.MENU){ if(hit(x,y,W()/2,485,230,70)){start();return true;} if(hit(x,y,W()/2,570,240,70)){showHowTo();return true;} if(hit(x,y,W()/2,650,240,70)){showBest();return true;} }
            else if(state==State.PLAYING){ if(x>W()-90&&y<105){state=State.PAUSED;return true;} targetX=clamp(x);dragging=true;return true; }
            else if(state==State.PAUSED){if(hit(x,y,W()/2,H()/2+55,230,70)){state=State.PLAYING;return true;}if(hit(x,y,W()/2,H()/2+130,230,70)){state=State.MENU;return true;}}
            else if(state==State.GAME_OVER){if(hit(x,y,W()/2,630,240,70)){start();return true;}if(hit(x,y,W()/2,705,240,70)){state=State.MENU;return true;}}
            else if(state==State.WIN){if(hit(x,y,W()/2,700,240,70)){start();return true;}if(hit(x,y,W()/2,770,240,70)){state=State.MENU;return true;}}
        } else if((e.getAction()==MotionEvent.ACTION_MOVE||e.getAction()==MotionEvent.ACTION_UP)&&state==State.PLAYING){targetX=clamp(x);dragging=e.getAction()!=MotionEvent.ACTION_UP;return true;}
        return true;
    }
    float clamp(float x){return Math.max(70,Math.min(W()-70,x));}
    boolean hit(float x,float y,float cx,float cy,float bw,float bh){return x>cx-bw/2&&x<cx+bw/2&&y>cy-bh/2&&y<cy+bh/2;}
    void showHowTo(){ new android.app.AlertDialog.Builder(getContext()).setTitle("HOW TO PLAY").setMessage("Catch the colorful balls with your head.\n\nAvoid the bombs!\n\nDrag left/right to move. Every ball = +1. Bomb hit = GAME OVER.\n\nLevels: 50, 100, 150 ... 500 points. Score is never capped at 50.").setPositiveButton("OK",null).show(); }
    void showBest(){ new android.app.AlertDialog.Builder(getContext()).setTitle("BEST SCORE").setMessage("Your best score is: "+best+"\n\nReach 500 to complete all 10 levels!").setPositiveButton("OK",null).show(); }
}
